jQuery( document ).ready(function( ) {
	jQuery('pre[data-show-toolbar="no"]').siblings('div.toolbar').hide();
});